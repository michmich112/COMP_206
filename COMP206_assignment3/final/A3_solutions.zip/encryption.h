#ifndef ENCRYPTION_H
# define ENCRYPTION_H

void decryptMessage(char* input, int key, int size);
void encryptMessage(char* input, int key, int size);
void reverse(char* strings, int size);

#endif
